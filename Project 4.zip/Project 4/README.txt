Name: Vincent Nguyen
ID: 30119507
Email: vincentnguye@umass.edu

App 1 and 2 were submitted early.
All apps compile.
DeleteLast method was not needed for App 3.

Other:
Number of BST levels may be incorrect. 
Graph works and looks pleasing but it does not look exactly like the example.


